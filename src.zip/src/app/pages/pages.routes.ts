import { Routes } from '@angular/router';


export default [
    { path: '**', redirectTo: '/notfound' }
] as Routes;
