import { Component } from '@angular/core';

@Component({
  selector: 'app-forget-pass',
  imports: [],
  templateUrl: './forget-pass.component.html',
  styleUrl: './forget-pass.component.css'
})
export class ForgetPassComponent {

}
