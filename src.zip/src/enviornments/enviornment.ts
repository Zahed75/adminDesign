// export const environment = {
//     production: true,
//     apiBaseUrl: 'https://app.bestelectronics.com.bd/api/v1'
// };
//
//


// Development environment configuration

export const environment = {
  production: false,
  apiBaseUrl: 'http://127.0.0.1:8000', // Local development URL
  wsHost: 'localhost:8000'
};
