export const RolePermissions = {
    AD: ['edit', 'delete', 'update', 'create', 'view'],
    CUS: ['edit', 'delete', 'update', 'create', 'view'],
    DES: ['edit', 'delete', 'update', 'create', 'view'],
    TM: ['edit', 'delete', 'update', 'create', 'view' ],

};


